#! /usr/bin/env python3

""" example module: extra.good.best.sigma """

def FunS():
	return "Sigma"

if __name__ == "__main__":
	print("I prefer to be a module")